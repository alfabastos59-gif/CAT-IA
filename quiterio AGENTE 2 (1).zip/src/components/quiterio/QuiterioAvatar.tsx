import { useEffect, useRef, useState } from "react";
import { motion, useReducedMotion } from "motion/react";
import quiterioVideo from "@/assets/quiterio_alpha.mp4.asset.json";
import poster from "@/assets/quiterio_transparent.png.asset.json";
import mouthTrack from "@/assets/quiterio-mouth.json";
import {
  CLOSED_MOUTH,
  analyzeLiveSpeech,
  applyAlphaMatte,
  interpolateMouthPoint,
  sampleSpeechTrack,
  smoothMouthShape,
  type MouthShape,
  type SpeechTrack,
} from "./avatar-media";

export type QuiterioState = "standby" | "listening" | "processing" | "speaking";

interface QuiterioAvatarProps {
  state: QuiterioState;
  analyser?: AnalyserNode | null;
  speechTrack?: SpeechTrack | null;
  audioElement?: HTMLAudioElement | null;
  className?: string;
}

export function QuiterioAvatar({
  state,
  analyser = null,
  speechTrack = null,
  audioElement = null,
  className = "h-64 w-64 md:h-80 md:w-80",
}: QuiterioAvatarProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const playbackRef = useRef({ state, analyser, speechTrack, audioElement });
  playbackRef.current = { state, analyser, speechTrack, audioElement };
  const [ready, setReady] = useState(false);
  const reduceMotion = useReducedMotion();

  useEffect(() => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;
    const ctx = canvas.getContext("2d");
    const buffer = document.createElement("canvas");
    buffer.width = 360;
    buffer.height = 960;
    const bufferCtx = buffer.getContext("2d", { willReadFrequently: true });
    if (!ctx || !bufferCtx) return;

    let raf = 0;
    let lastDraw = 0;
    let mouth: MouthShape = { ...CLOSED_MOUTH };
    let timeSamples = new Uint8Array(256);
    let freqSamples = new Uint8Array(128);
    let failed = false;
    const trackedPoints = mouthTrack.points as [number, number][];

    const draw = (now: number) => {
      raf = requestAnimationFrame(draw);
      const { state: current, analyser: audio, speechTrack: track, audioElement: el } = playbackRef.current;
      const minInterval = current === "speaking" ? 1000 / 60 : 1000 / 30;
      if (failed || video.readyState < 2 || now - lastDraw < minInterval) return;
      const dt = lastDraw ? now - lastDraw : 16;
      lastDraw = now;
      try {
        bufferCtx.drawImage(video, 0, 0, 360, 960);
        const image = bufferCtx.getImageData(0, 0, 360, 480);
        const matte = bufferCtx.getImageData(0, 480, 360, 480);
        applyAlphaMatte(image.data, matte.data);
        ctx.putImageData(image, 0, 0);

        let target: MouthShape = CLOSED_MOUTH;
        if (current === "speaking") {
          if (track && el && !el.paused && !el.ended) {
            target = sampleSpeechTrack(track, el.currentTime, 0.035);
          } else if (audio) {
            if (timeSamples.length !== audio.fftSize) timeSamples = new Uint8Array(audio.fftSize);
            if (freqSamples.length !== audio.frequencyBinCount) freqSamples = new Uint8Array(audio.frequencyBinCount);
            audio.getByteTimeDomainData(timeSamples);
            audio.getByteFrequencyData(freqSamples);
            target = analyzeLiveSpeech(timeSamples, freqSamples, audio.context.sampleRate);
          } else {
            // Browser speech provides no waveform: use a gentle approximate cadence.
            const cadence = Math.max(0, Math.sin(now / 85) * Math.sin(now / 173)) * 0.65;
            target = { open: cadence, spread: 0.45 + 0.25 * Math.sin(now / 210) };
          }
        }
        mouth = current === "speaking" ? smoothMouthShape(mouth, target, dt) : { ...CLOSED_MOUTH };

        // Smoothly track the nose between frames so the mouth glides with head turns.
        const point = interpolateMouthPoint(trackedPoints, video.currentTime, mouthTrack.fps);
        if (mouth.open > 0.04 && point) {
          const [noseX, noseY] = point;
          const x = noseX - (noseX - 180) * 0.07;
          const y = noseY + 17;
          // Derive the mouth and tongue pigments from the kitten bitmap, not page colors.
          const index = (Math.round(noseY) * 360 + Math.round(noseX)) * 4;
          const r = image.data[index] ?? 220;
          const g = image.data[index + 1] ?? 100;
          const b = image.data[index + 2] ?? 100;
          const rx = 5.2 + mouth.spread * 4.4 + mouth.open * 1.4;
          const ry = 1.1 + mouth.open * 8.2;
          const cy = y + ry * 0.52;

          ctx.save();
          ctx.beginPath();
          ctx.ellipse(x, cy, rx, ry, 0, 0, Math.PI * 2);
          ctx.fillStyle = `rgb(${Math.round(r * 0.26)} ${Math.round(g * 0.22)} ${Math.round(b * 0.22)})`;
          ctx.fill();
          ctx.clip();
          if (mouth.open > 0.22) {
            ctx.fillStyle = `rgb(${r} ${g} ${b})`;
            ctx.beginPath();
            ctx.ellipse(x, cy + ry * 0.62, rx * 0.68, ry * 0.48, 0, 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.restore();

          ctx.strokeStyle = `rgb(${Math.round(r * 0.18)} ${Math.round(g * 0.15)} ${Math.round(b * 0.15)} / 0.65)`;
          ctx.lineWidth = 1.1;
          ctx.beginPath();
          ctx.ellipse(x, cy, rx, ry, 0, Math.PI * 1.12, Math.PI * 1.88);
          ctx.stroke();
        }
        setReady(true);
      } catch {
        failed = true;
        setReady(false);
      }
    };
    const start = () => {
      video.play().catch(() => {});
    };
    video.addEventListener("loadeddata", start);
    if (video.readyState >= 2) start();
    raf = requestAnimationFrame(draw);
    return () => {
      cancelAnimationFrame(raf);
      video.removeEventListener("loadeddata", start);
      video.pause();
    };
  }, []);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    if (reduceMotion && state !== "speaking") video.pause();
    else video.play().catch(() => {});
  }, [reduceMotion, state]);

  return (
    <div className={`relative flex select-none items-center justify-center ${className}`}>
      <motion.div
        className="relative h-full w-full"
        animate={reduceMotion ? { y: 0 } : { y: [0, -5, 0] }}
        transition={{ repeat: Infinity, duration: 3.4, ease: "easeInOut" }}
      >
        <img src={poster.url} alt="Quitério, o gatinho da biblioteca" className={`absolute inset-0 h-full w-full object-contain ${ready ? "invisible" : ""}`} />
        <canvas ref={canvasRef} width={360} height={480} role="img" aria-label="Quitério, o gatinho animado da biblioteca" data-state={state} className={`h-full w-full object-contain ${ready ? "" : "invisible"}`} />
        <video ref={videoRef} src={quiterioVideo.url} loop muted playsInline autoPlay preload="auto" crossOrigin="anonymous" className="hidden" aria-hidden="true" />
      </motion.div>
    </div>
  );
}