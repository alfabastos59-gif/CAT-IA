import { useEffect, useRef } from "react";

/** Barras de onda: usa o analisador real quando houver, senão simula. */
export function Waveform({ active, analyser }: { active: boolean; analyser: AnalyserNode | null }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const bars = Array.from(ref.current?.children ?? []) as HTMLElement[];
    let raf = 0;
    const buf = analyser ? new Uint8Array(analyser.frequencyBinCount) : null;
    const tick = (t: number) => {
      if (analyser && buf) analyser.getByteFrequencyData(buf);
      bars.forEach((b, i) => {
        let v = 0.08;
        if (active) v = buf ? Math.max(0.08, (buf[2 + i * 3] ?? 0) / 255) : 0.25 + 0.6 * Math.abs(Math.sin(t / 140 + i * 0.7) * Math.sin(t / 310 + i));
        b.style.transform = `scaleY(${v})`;
      });
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [active, analyser]);
  return (
    <div ref={ref} className="flex h-10 items-center gap-1" aria-hidden>
      {Array.from({ length: 18 }).map((_, i) => <span key={i} className="h-full w-1.5 origin-center rounded-full bg-accent transition-transform duration-75" />)}
    </div>
  );
}
