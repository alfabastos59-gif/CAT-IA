export interface MouthShape {
  open: number;
  spread: number;
}

export interface SpeechTrack {
  fps: number;
  duration: number;
  frames: MouthShape[];
}

export const CLOSED_MOUTH: MouthShape = { open: 0, spread: 0.5 };

/** The video stores color in its upper half and a grayscale alpha matte below it. */
export function applyAlphaMatte(color: Uint8ClampedArray, matte: Uint8ClampedArray) {
  for (let i = 0; i < color.length; i += 4) {
    const alpha = matte[i] ?? 0;
    color[i + 3] = alpha < 12 ? 0 : alpha > 243 ? 255 : alpha;
  }
}

export function speechEnergy(samples: Uint8Array) {
  if (!samples.length) return 0;
  let sum = 0;
  for (const sample of samples) sum += ((sample - 128) / 128) ** 2;
  return Math.min(1, Math.max(0, (Math.sqrt(sum / samples.length) - 0.012) * 8));
}

const clamp01 = (v: number) => Math.min(1, Math.max(0, v));

/** Pre-analyzes decoded Fish Audio PCM into normalized mouth shapes synced to playback time. */
export function buildSpeechTrack(samples: Float32Array, sampleRate: number, fps = 50): SpeechTrack {
  if (!samples.length || sampleRate <= 0) return { fps, duration: 0, frames: [] };
  const hop = Math.max(1, Math.round(sampleRate / fps));
  const frameCount = Math.ceil(samples.length / hop);
  const rmsList = new Float32Array(frameCount);
  const zcrList = new Float32Array(frameCount);

  for (let f = 0; f < frameCount; f++) {
    const start = f * hop;
    const end = Math.min(samples.length, start + hop);
    let sumSq = 0;
    let crossings = 0;
    let prev = samples[start] ?? 0;
    for (let i = start; i < end; i++) {
      const s = samples[i] ?? 0;
      sumSq += s * s;
      if ((s >= 0 && prev < 0) || (s < 0 && prev >= 0)) crossings++;
      prev = s;
    }
    const count = Math.max(1, end - start);
    rmsList[f] = Math.sqrt(sumSq / count);
    // Approximate dominant frequency via zero-crossing rate (Hz).
    zcrList[f] = (crossings * sampleRate) / (2 * count);
  }

  const sorted = Array.from(rmsList).sort((a, b) => a - b);
  const p92 = sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * 0.92))] ?? 0;
  const refPeak = Math.max(p92, 0.035);
  const noiseFloor = Math.max(refPeak * 0.08, 0.008);

  const frames: MouthShape[] = new Array(frameCount);
  for (let f = 0; f < frameCount; f++) {
    const rms = rmsList[f] ?? 0;
    if (rms <= noiseFloor) {
      frames[f] = { open: 0, spread: 0.5 };
      continue;
    }
    const energy = clamp01((rms - noiseFloor) / (refPeak - noiseFloor));
    const freq = zcrList[f] ?? 600;
    // High ZCR (>2400 Hz) indicates sibilants/fricatives ("s", "f", "ch"): narrower vertical opening, wider lips.
    const sibilance = clamp01((freq - 1800) / 2400);
    const open = clamp01(Math.pow(energy, 0.78) * (1 - sibilance * 0.62));
    // Low frequency ("o", "u") -> rounder (lower spread); mid/high ("e", "i", "s") -> wider spread.
    const spread = clamp01(0.22 + clamp01((freq - 350) / 2200) * 0.68);
    frames[f] = { open, spread };
  }

  return { fps, duration: samples.length / sampleRate, frames };
}

export function sampleSpeechTrack(track: SpeechTrack, timeSec: number, lookaheadSec = 0.035): MouthShape {
  if (!track.frames.length) return CLOSED_MOUTH;
  const t = timeSec + lookaheadSec;
  if (t < 0 || t > track.duration) return CLOSED_MOUTH;
  const exact = t * track.fps;
  const i0 = Math.min(track.frames.length - 1, Math.max(0, Math.floor(exact)));
  const i1 = Math.min(track.frames.length - 1, i0 + 1);
  const frac = exact - i0;
  const a = track.frames[i0] ?? CLOSED_MOUTH;
  const b = track.frames[i1] ?? a;
  return {
    open: a.open + (b.open - a.open) * frac,
    spread: a.spread + (b.spread - a.spread) * frac,
  };
}

/** Live AnalyserNode fallback using speech frequency bands + time-domain RMS. */
export function analyzeLiveSpeech(timeSamples: Uint8Array, freqSamples: Uint8Array, sampleRate: number): MouthShape {
  const rmsEnergy = speechEnergy(timeSamples);
  if (!freqSamples.length || sampleRate <= 0) return { open: rmsEnergy, spread: 0.5 };
  const binHz = sampleRate / (freqSamples.length * 2);
  const bandAvg = (minHz: number, maxHz: number) => {
    const start = Math.max(0, Math.floor(minHz / binHz));
    const end = Math.min(freqSamples.length - 1, Math.ceil(maxHz / binHz));
    if (end < start) return 0;
    let sum = 0;
    for (let i = start; i <= end; i++) sum += (freqSamples[i] ?? 0) / 255;
    return sum / (end - start + 1);
  };
  const low = bandAvg(150, 900);
  const mid = bandAvg(900, 2600);
  const high = bandAvg(2600, 6000);
  const vocal = low * 0.55 + mid * 0.45;
  const sibilance = high > vocal * 1.15 ? clamp01((high - vocal) * 1.8) : 0;
  const rawOpen = Math.max(rmsEnergy * 0.75, clamp01((vocal - 0.08) * 1.9));
  const open = clamp01(rawOpen * (1 - sibilance * 0.55));
  const spread = clamp01(0.28 + (mid + high * 0.8 - low * 0.4) * 0.8);
  return open < 0.04 ? CLOSED_MOUTH : { open, spread };
}

/** Frame-rate independent smoothing with fast attack on syllable onset and smooth release. */
export function smoothMouthShape(current: MouthShape, target: MouthShape, dtMs: number): MouthShape {
  const dt = Math.min(100, Math.max(1, dtMs));
  const openTau = target.open > current.open ? 22 : 55;
  const openAlpha = 1 - Math.exp(-dt / openTau);
  const spreadAlpha = 1 - Math.exp(-dt / 45);
  const nextOpen = current.open + (target.open - current.open) * openAlpha;
  const nextSpread = current.spread + (target.spread - current.spread) * spreadAlpha;
  return {
    open: target.open < 0.02 && nextOpen < 0.03 ? 0 : nextOpen,
    spread: nextSpread,
  };
}

/** Smoothly interpolates nose/mouth tracking coordinates between 24fps video frames. */
export function interpolateMouthPoint(
  points: readonly (readonly [number, number])[],
  timeSec: number,
  fps: number,
): [number, number] | null {
  if (!points.length) return null;
  const exact = Math.max(0, timeSec * fps) % points.length;
  const i0 = Math.floor(exact);
  const i1 = (i0 + 1) % points.length;
  const frac = exact - i0;
  const p0 = points[i0];
  const p1 = points[i1] ?? p0;
  if (!p0 || !p1) return null;
  return [p0[0] + (p1[0] - p0[0]) * frac, p0[1] + (p1[1] - p0[1]) * frac];
}