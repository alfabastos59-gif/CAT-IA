import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useCallback, useEffect, useRef, useState } from "react";
import { Send, Volume2, VolumeX } from "lucide-react";
import { QuiterioAvatar, type QuiterioState } from "@/components/quiterio/QuiterioAvatar";
import { buildSpeechTrack, type SpeechTrack } from "@/components/quiterio/avatar-media";
import { Waveform } from "@/components/quiterio/Waveform";
import { ECHO_COOLDOWN_MS, voiceQuestion } from "@/lib/voice-wake";
import { conversarComQuiterio } from "@/lib/quiterio.functions";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Quitério — o gatinho da biblioteca" },
      {
        name: "description",
        content: "Converse por voz ou texto com o Quitério, o gatinho que recomenda livros da Biblioteca do Colégio Maria Quitéria.",
      },
      { property: "og:title", content: "Quitério — o gatinho da biblioteca" },
      { property: "og:description", content: "Recomendações de livros, autores e dicas da biblioteca, com voz." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

type Msg = { role: "user" | "assistant"; content: string };
const SAUDACAO = "Oi! Eu sou o Quitério, o gatinho da biblioteca. Quer uma dica de livro de aventura, ficção ou um clássico?";
const STATUS: Record<QuiterioState, string> = {
  standby: "Descansando",
  listening: "Ouvindo",
  processing: "Pensando",
  speaking: "Falando",
};


function Index() {
  const conversar = useServerFn(conversarComQuiterio);
  const [msgs, setMsgs] = useState<Msg[]>([{ role: "assistant", content: SAUDACAO }]);
  const [state, setState] = useState<QuiterioState>("standby");
  const [texto, setTexto] = useState("");
  const [muted, setMuted] = useState(false);
  const [micError, setMicError] = useState<string | null>(null);
  const [voiceSource, setVoiceSource] = useState<"fish" | "navegador" | null>(null);
  const [analyser, setAnalyser] = useState<AnalyserNode | null>(null);
  const [speechTrack, setSpeechTrack] = useState<SpeechTrack | null>(null);
  const [srSupported, setSrSupported] = useState(true);
  const [parcial, setParcial] = useState("");

  const msgsRef = useRef(msgs);
  msgsRef.current = msgs;
  const mutedRef = useRef(muted);
  mutedRef.current = muted;
  const busyRef = useRef(false);
  const recRef = useRef<any>(null);
  const armedUntilRef = useRef(0);
  const resumeMicRef = useRef<(() => void) | null>(null);
  const micTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const ctxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const speechRequestRef = useRef<AbortController | null>(null);
  const finishSpeechRef = useRef<(() => void) | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs]);
  useEffect(() => {
    const w = window as any;
    setSrSupported(Boolean(w.SpeechRecognition || w.webkitSpeechRecognition));
  }, []);

  const prepararAudio = useCallback(() => {
    if (!ctxRef.current) {
      const audio = audioRef.current ?? new Audio();
      audioRef.current = audio;
      const ctx = new AudioContext();
      const src = ctx.createMediaElementSource(audio);
      const an = ctx.createAnalyser();
      an.fftSize = 512;
      an.smoothingTimeConstant = 0.25;
      src.connect(an);
      an.connect(ctx.destination);
      ctxRef.current = ctx;
      analyserRef.current = an;
    }
    return ctxRef.current.resume();
  }, []);

  const falarNavegador = (t: string) =>
    new Promise<void>((resolve) => {
      if (!("speechSynthesis" in window)) return resolve();
      const u = new SpeechSynthesisUtterance(t);
      u.lang = "pt-BR";
      u.pitch = 1.15;
      const v = speechSynthesis.getVoices().find((x) => x.lang.startsWith("pt"));
      if (v) u.voice = v;
      finishSpeechRef.current = resolve;
      u.onstart = () => {
        setState("speaking");
        window.__lovableEvents?.track?.("project.response_spoken", { voice_source: "browser" });
      };
      u.onend = () => { finishSpeechRef.current = null; resolve(); };
      u.onerror = () => { finishSpeechRef.current = null; resolve(); };
      setVoiceSource("navegador");
      setAnalyser(null);
      speechSynthesis.cancel();
      speechSynthesis.speak(u);
    });

  const falar = useCallback(async (t: string) => {
    if (mutedRef.current) return;
    const controller = new AbortController();
    speechRequestRef.current = controller;
    let url: string | null = null;
    setAnalyser(null);
    setSpeechTrack(null);
    try {
      const r = await fetch("/api/tts", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ text: t }),
        signal: controller.signal,
      });
      if (!r.ok || r.status === 204) throw new Error(String(r.status));
      const rawAudio = await r.arrayBuffer();
      url = URL.createObjectURL(new Blob([rawAudio], { type: r.headers.get("content-type") || "audio/mpeg" }));
      if (controller.signal.aborted || mutedRef.current) return;
      await prepararAudio();
      const audio = audioRef.current;
      if (!audio || controller.signal.aborted || mutedRef.current) return;
      const audioCtx = ctxRef.current;
      if (audioCtx) {
        void audioCtx
          .decodeAudioData(rawAudio.slice(0))
          .then((decoded) => {
            if (!controller.signal.aborted && !mutedRef.current) {
              setSpeechTrack(buildSpeechTrack(decoded.getChannelData(0), decoded.sampleRate));
            }
          })
          .catch(() => {});
      }
      audio.src = url;
      await new Promise<void>((resolve, reject) => {
        let tracked = false;
        finishSpeechRef.current = resolve;
        audio.onplaying = () => {
          setAnalyser(analyserRef.current);
          setVoiceSource("fish");
          setState("speaking");
          if (!tracked) {
            tracked = true;
            window.__lovableEvents?.track?.("project.response_spoken", { voice_source: "fish" });
          }
        };
        audio.onended = () => resolve();
        audio.onerror = () => reject(new Error("audio"));
        audio.play().catch(reject);
      });
    } catch {
      if (!controller.signal.aborted && !mutedRef.current) await falarNavegador(t);
    } finally {
      if (url) URL.revokeObjectURL(url);
      finishSpeechRef.current = null;
      if (speechRequestRef.current === controller) speechRequestRef.current = null;
      setAnalyser(null);
      setSpeechTrack(null);
    }
  }, [prepararAudio]);

  const pararFala = () => {
    speechRequestRef.current?.abort();
    audioRef.current?.pause();
    if ("speechSynthesis" in window) speechSynthesis.cancel();
    finishSpeechRef.current?.();
    finishSpeechRef.current = null;
    setAnalyser(null);
    setSpeechTrack(null);
    setState("standby");
  };

  const enviar = useCallback(
    async (pergunta: string, origem: "text" | "voice" | "suggestion" = "text") => {
      const q = pergunta.trim();
      if (!q || busyRef.current) return;
      window.__lovableEvents?.track?.("project.question_sent", { input_method: origem });
      // Unlock audio during the user's gesture, before waiting for the answer.
      if (!mutedRef.current) void prepararAudio().catch(() => {});
      busyRef.current = true;
      armedUntilRef.current = 0;
      if (micTimerRef.current) clearTimeout(micTimerRef.current);
      const recognition = recRef.current;
      recRef.current = null;
      recognition?.abort();
      const novo: Msg[] = [...msgsRef.current, { role: "user", content: q }];
      setMsgs(novo);
      setTexto("");
      setParcial("");
      setState("processing");
      try {
        const { reply } = await conversar({ data: { messages: novo.slice(-12) } });
        setMsgs((m) => [...m, { role: "assistant", content: reply }]);
        await falar(reply);
      } catch {
        setMsgs((m) => [...m, { role: "assistant", content: "Miau! Não consegui responder agora. Tenta de novo?" }]);
      } finally {
        busyRef.current = false;
        setState("standby");
        micTimerRef.current = setTimeout(() => resumeMicRef.current?.(), ECHO_COOLDOWN_MS);
      }
    },
    [conversar, falar, prepararAudio],
  );

  const enviarRef = useRef(enviar);
  enviarRef.current = enviar;

  useEffect(() => {
    const w = window as any;
    const SR = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!SR) return;
    let disposed = false;
    let blocked = false;
    const start = () => {
      if (disposed || blocked || busyRef.current || recRef.current || document.hidden) return;
      const rec = new SR();
      rec.lang = "pt-BR";
      rec.continuous = true;
      rec.interimResults = true;
      recRef.current = rec;
      rec.onresult = (ev: any) => {
        if (disposed || busyRef.current || recRef.current !== rec) return;
        for (let i = ev.resultIndex; i < ev.results.length; i++) {
          if (busyRef.current || recRef.current !== rec) return;
          const result = ev.results[i];
          const text: string = result[0].transcript;
          if (!result.isFinal) continue;
          const parsed = voiceQuestion(text, armedUntilRef.current, Date.now());
          armedUntilRef.current = parsed.armedUntil;
          setParcial("");
          if (parsed.question) {
            void enviarRef.current(parsed.question, "voice");
            return;
          }
        }
      };
      rec.onstart = () => {
        if (recRef.current === rec && !busyRef.current) {
          setMicError(null);
          setState("listening");
        }
      };
      rec.onend = () => {
        if (recRef.current !== rec) return;
        recRef.current = null;
        if (!disposed && !blocked && !busyRef.current) {
          micTimerRef.current = setTimeout(start, ECHO_COOLDOWN_MS);
        }
      };
      rec.onerror = (e: any) => {
        if (recRef.current !== rec || disposed) return;
        if (["not-allowed", "service-not-allowed", "audio-capture"].includes(e.error)) {
          blocked = true;
          recRef.current = null;
          rec.abort();
          setState("standby");
          setMicError(e.error === "audio-capture" ? "Microfone indisponível." : "Permissão do microfone necessária para conversar por voz.");
        }
      };
      try {
        rec.start();
      } catch {
        blocked = true;
        recRef.current = null;
        setMicError("Não foi possível ativar o microfone neste navegador.");
      }
    };
    const visibility = () => {
      if (document.hidden) {
        armedUntilRef.current = 0;
        const rec = recRef.current;
        recRef.current = null;
        rec?.abort();
        if (!busyRef.current) setState("standby");
      } else start();
    };
    resumeMicRef.current = start;
    start();
    document.addEventListener("visibilitychange", visibility);
    return () => {
      disposed = true;
      resumeMicRef.current = null;
      if (micTimerRef.current) clearTimeout(micTimerRef.current);
      document.removeEventListener("visibilitychange", visibility);
      const rec = recRef.current;
      recRef.current = null;
      rec?.abort();
    };
  }, []);

  useEffect(() => () => {
    recRef.current?.stop();
    speechRequestRef.current?.abort();
    audioRef.current?.pause();
    finishSpeechRef.current?.();
    if ("speechSynthesis" in window) speechSynthesis.cancel();
    void ctxRef.current?.close();
  }, []);

  return (
    <main className="min-h-screen bg-background text-foreground">
      <div className="mx-auto grid max-w-6xl grid-cols-1 gap-4 px-3 py-4 sm:gap-8 sm:px-4 sm:py-8 lg:grid-cols-[1fr_1.15fr] lg:py-12">
        <section className="flex min-w-0 flex-col items-center gap-3 sm:gap-6">
          <h1 className="sr-only">Quitério</h1>
          <div className="relative px-6 pb-5 pt-6 sm:px-10 sm:pb-8 sm:pt-10">
            <QuiterioAvatar
              state={state}
              analyser={voiceSource === "fish" ? analyser : null}
              speechTrack={voiceSource === "fish" ? speechTrack : null}
              audioElement={voiceSource === "fish" ? audioRef.current : null}
              className="h-52 w-52 sm:h-64 sm:w-64 md:h-80 md:w-80"
            />
          </div>

          <div className="w-full max-w-sm rounded-2xl border bg-card p-3 sm:p-4 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className={`h-2.5 w-2.5 rounded-full ${state === "standby" ? "bg-muted-foreground" : "animate-pulse bg-accent"}`} />
                <span className="font-semibold">{STATUS[state]}</span>
              </div>
              <button
                onClick={() => {
                  mutedRef.current = !muted;
                  setMuted((m) => !m);
                  if (!muted) pararFala();
                }}
                className="inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-sm hover:bg-secondary"
                aria-label={muted ? "Desmutar voz" : "Mutar voz"}
              >
                {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                {muted ? "Mudo" : "Som ligado"}
              </button>
            </div>
            <div className="mt-2 flex items-center justify-center rounded-xl sm:mt-3 bg-secondary py-2">
              <Waveform active={state === "speaking"} analyser={voiceSource === "fish" ? analyser : null} />
            </div>
          </div>
        </section>

        <section className="flex min-w-0 min-h-[28rem] flex-col rounded-3xl sm:min-h-[32rem] border bg-card shadow-sm">
          {(!srSupported || micError) && (
            <p role="status" className="border-b p-3 text-xs text-destructive sm:p-4">
              {!srSupported ? "Seu navegador não reconhece voz. Use o Chrome ou Edge, ou escreva abaixo." : micError}
            </p>
          )}

          <div className="flex-1 space-y-3 overflow-y-auto p-3 sm:p-4" style={{ maxHeight: "min(28rem, 60vh)" }}>
            {msgs.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <p
                  className={`max-w-[90%] rounded-2xl px-4 py-2.5 text-[15px] leading-relaxed sm:max-w-[85%] sm:text-base ${
                    m.role === "user"
                      ? "rounded-br-sm bg-primary text-primary-foreground"
                      : "rounded-bl-sm bg-secondary text-secondary-foreground"
                  }`}
                >
                  {m.content}
                </p>
              </div>
            ))}
            {parcial && <p className="text-right text-sm italic text-muted-foreground">{parcial}…</p>}
            <div ref={endRef} />
          </div>

          <div className="flex gap-2 overflow-x-auto px-3 pb-2 sm:flex-wrap sm:overflow-visible sm:px-4">
            {[
              "Me indica um livro de aventura",
              "Tem ficção disponível?",
              "Quero um clássico brasileiro",
              "Como funciona o empréstimo?",
            ].map((s) => (
              <button key={s} onClick={() => enviar(s, "suggestion")} className="shrink-0 whitespace-nowrap rounded-full border px-3 py-1.5 text-xs hover:bg-secondary">
                {s}
              </button>
            ))}
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void enviar(texto, "text");
            }}
            className="flex gap-2 border-t p-3 sm:p-4"
          >
            <input
              value={texto}
              onChange={(e) => setTexto(e.target.value)}
              placeholder="Escreva para o Quitério…"
              className="min-w-0 flex-1 rounded-full border bg-background px-4 py-2.5 text-base outline-none focus:ring-2 focus:ring-ring"
            />
            <button
              type="submit"
              disabled={!texto.trim() || state === "processing"}
              aria-label="Enviar"
              className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground disabled:opacity-50"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </section>
      </div>
    </main>
  );
}
