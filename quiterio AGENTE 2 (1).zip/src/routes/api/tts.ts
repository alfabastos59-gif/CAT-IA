import { createFileRoute } from "@tanstack/react-router";

const DEFAULT_FISH_VOICE_ID = "7f2c0deba7a644589858aae134dcb200";

// Proxy seguro para o Fish Audio: a chave fica no servidor e o navegador chama a mesma origem.
export const Route = createFileRoute("/api/tts")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env["FISH_API_KEY"]?.trim();
        const voice = process.env["FISH_VOICE_ID"]?.trim() || DEFAULT_FISH_VOICE_ID;
        // Sem chave: 204 avisa o navegador para usar a voz de reserva, sem gerar erro.
        if (!key) return new Response(null, { status: 204, headers: { "x-tts": "unconfigured" } });
        let text = "";
        try {
          text = String(((await request.json()) as { text?: unknown }).text ?? "").trim();
        } catch {
          /* vazio */
        }
        if (!text || text.length > 1200) return new Response("Texto inválido", { status: 400 });
        const headers: Record<string, string> = {
          Authorization: `Bearer ${key}`,
          "Content-Type": "application/json",
          model: process.env["FISH_MODEL"]?.trim() || "s2.1-pro-free",
        };
        const resp = await fetch("https://api.fish.audio/v1/tts", {
          method: "POST",
          headers,
          body: JSON.stringify({
            text,
            reference_id: voice,
            format: "mp3",
            mp3_bitrate: 128,
            latency: "balanced",
            normalize: true,
          }),
        });
        if (!resp.ok || !resp.body) {
          console.error("Fish Audio", resp.status, (await resp.text().catch(() => "")).slice(0, 200));
          return new Response("Falha no TTS", { status: 502 });
        }
        return new Response(resp.body, {
          headers: { "content-type": "audio/mpeg", "cache-control": "no-store" },
        });
      },
    },
  },
});