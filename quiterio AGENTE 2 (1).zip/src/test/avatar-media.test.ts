import { describe, expect, it } from "vitest";
import {
  analyzeLiveSpeech,
  applyAlphaMatte,
  buildSpeechTrack,
  interpolateMouthPoint,
  sampleSpeechTrack,
  smoothMouthShape,
  speechEnergy,
} from "@/components/quiterio/avatar-media";

function sineWave(freqHz: number, amplitude: number, durationSec: number, sampleRate = 16000) {
  const out = new Float32Array(Math.round(durationSec * sampleRate));
  for (let i = 0; i < out.length; i++) out[i] = Math.sin((2 * Math.PI * freqHz * i) / sampleRate) * amplitude;
  return out;
}

describe("transparent kitten media", () => {
  it("removes the background while retaining the kitten and soft edges", () => {
    const pixels = new Uint8ClampedArray([70, 180, 60, 255, 230, 130, 40, 255, 140, 100, 70, 255]);
    applyAlphaMatte(pixels, new Uint8ClampedArray([5, 5, 5, 255, 250, 250, 250, 255, 120, 120, 120, 255]));
    expect([...pixels]).toEqual([70, 180, 60, 0, 230, 130, 40, 255, 140, 100, 70, 120]);
  });
  it("keeps the mouth closed during audio silence", () => {
    expect(speechEnergy(new Uint8Array([128, 128, 128, 128]))).toBe(0);
  });
  it("opens the mouth in proportion to the actual voice amplitude", () => {
    const quiet = speechEnergy(new Uint8Array([124, 132, 124, 132]));
    const loud = speechEnergy(new Uint8Array([110, 146, 110, 146]));
    expect(quiet).toBeGreaterThan(0);
    expect(loud).toBeGreaterThan(quiet);
    expect(loud).toBeLessThanOrEqual(1);
  });
  it("syncs Fish Audio speech track to syllables, pauses, and vowel vs sibilant shapes", () => {
    const sr = 16000;
    const silence = new Float32Array(sr * 0.2);
    const vowel = sineWave(500, 0.4, 0.2, sr);
    const sibilant = sineWave(4200, 0.4, 0.2, sr);
    const pcm = new Float32Array(silence.length + vowel.length + sibilant.length);
    pcm.set(silence, 0);
    pcm.set(vowel, silence.length);
    pcm.set(sibilant, silence.length + vowel.length);

    const track = buildSpeechTrack(pcm, sr, 50);
    const duringPause = sampleSpeechTrack(track, 0.05, 0);
    const duringVowel = sampleSpeechTrack(track, 0.3, 0);
    const duringSibilant = sampleSpeechTrack(track, 0.5, 0);
    const withLookahead = sampleSpeechTrack(track, 0.18, 0.035);

    expect(duringPause.open).toBe(0);
    expect(duringVowel.open).toBeGreaterThan(0.6);
    expect(duringSibilant.open).toBeLessThan(duringVowel.open);
    expect(duringSibilant.spread).toBeGreaterThan(duringVowel.spread);
    expect(withLookahead.open).toBeGreaterThan(0.3);
  });
  it("analyzes live speech frequency bands for fallback lip sync", () => {
    const quietTime = new Uint8Array(128).fill(128);
    const vowelFreq = new Uint8Array(128);
    vowelFreq.fill(180, 2, 12);
    const sibilantFreq = new Uint8Array(128);
    sibilantFreq.fill(180, 40, 80);

    const vowel = analyzeLiveSpeech(quietTime, vowelFreq, 48000);
    const sibilant = analyzeLiveSpeech(quietTime, sibilantFreq, 48000);
    expect(vowel.open).toBeGreaterThan(0.4);
    expect(sibilant.open).toBeLessThan(vowel.open);
  });
  it("opens faster on syllable onset than it closes on release", () => {
    const opening = smoothMouthShape({ open: 0, spread: 0.5 }, { open: 1, spread: 0.5 }, 20);
    const closing = smoothMouthShape({ open: 1, spread: 0.5 }, { open: 0, spread: 0.5 }, 20);
    expect(opening.open).toBeGreaterThan(1 - closing.open);
  });
  it("interpolates mouth tracking smoothly between video frames", () => {
    const mid = interpolateMouthPoint([[100, 200], [120, 220]], 0.5 / 24, 24);
    expect(mid).toEqual([110, 210]);
  });
});