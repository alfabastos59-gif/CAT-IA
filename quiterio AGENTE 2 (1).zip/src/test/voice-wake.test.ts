import { describe, expect, it } from "vitest";
import { ECHO_COOLDOWN_MS, voiceQuestion } from "@/lib/voice-wake";

describe("Quitério wake word", () => {
  it("ignores questions without Quitério", () => {
    expect(voiceQuestion("Tem aventura?", 0, 1000).question).toBeNull();
  });
  it("accepts the question after Quitério in the same phrase", () => {
    expect(voiceQuestion("Quitério, tem aventura?", 0, 1000)).toEqual({ question: "tem aventura?", armedUntil: 0 });
  });
  it("accepts the next phrase after hearing Quitério alone, only once", () => {
    const armed = voiceQuestion("Quitério", 0, 1000);
    expect(armed.question).toBeNull();
    const next = voiceQuestion("Tem aventura?", armed.armedUntil, 2000);
    expect(next.question).toBe("Tem aventura?");
    expect(voiceQuestion("Outra pergunta", next.armedUntil, 3000).question).toBeNull();
  });
  it("expires an abandoned wake word", () => {
    expect(voiceQuestion("Tem aventura?", 9000, 10000).question).toBeNull();
  });
  it("allows half a second for speaker echo to settle", () => {
    expect(ECHO_COOLDOWN_MS).toBe(500);
  });
});