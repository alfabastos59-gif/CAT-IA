import { describe, expect, it } from "vitest";
import { REGRAS_EMPRESTIMO } from "@/lib/biblioteca";
describe("regras de empréstimo", () => {
  it("até 2 livros", () => expect(REGRAS_EMPRESTIMO).toContain("até 2 livros"));
  it("14 dias", () => expect(REGRAS_EMPRESTIMO).toContain("14 dias corridos"));
  it("renovação +7", () => expect(REGRAS_EMPRESTIMO).toContain("7 dias"));
});
