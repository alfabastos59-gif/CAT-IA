import { describe, expect, it } from "vitest";
import { MISSAO_QUITERIO as m } from "@/lib/missao-quiterio";

describe("regras oficiais da Missão Quitério", () => {
  it("acesso usa código individual e leva à biblioteca", () => {
    expect(m.acesso.codigoIndividual).toBe(true);
    expect(m.acesso.destino).toBe("biblioteca");
  });
  it("progresso é salvo por aluno", () => expect(m.acesso.progressoPorAluno).toBe(true));
  it("até 5 livros geram desafios", () => expect(m.desafios.maxLivros).toBe(5));
  it("livros têm 4 perguntas", () => expect(m.desafios.perguntasLivro).toBe(4));
  it("surpresa tem 6 perguntas", () => expect(m.desafios.perguntasSurpresa).toBe(6));
  it("surpresa está disponível sem livros", () => expect(m.desafios.surpresaSemLivros).toBe(true));
  it("desafios têm 3 corações", () => expect(m.desafios.coracoes).toBe(3));
  it("estrelas vão de 0 a 3", () => {
    expect(m.desafios.estrelasMin).toBe(0);
    expect(m.desafios.estrelasMax).toBe(3);
  });
  it("somente livros dão bônus", () => expect(m.bonus.somenteLivros).toBe(true));
  it("bônus exige melhora de nota", () => expect(m.bonus.exigeMelhora).toBe(true));
  it("cada bônus vale uma corrida", () => expect(m.bonus.corridasPorBonus).toBe(1));
  it("corrida tem 3 corações", () => expect(m.corrida.coracoes).toBe(3));
  it("cinco fases seguem a ordem informada", () => {
    expect(m.corrida.fases).toEqual(["Fazenda", "Milharal", "Sertão", "Floresta", "Cidade à noite"]);
  });
  it("tratores aparecem na fase 4", () => expect(m.corrida.faseTratores).toBe(4));
  it("miado sônico é da fase 4", () => expect(m.corrida.faseMiadoSonico).toBe(4));
  it("Puff é resgatada na biblioteca na fase 5", () => {
    expect(m.corrida.faseResgate).toBe(5);
    expect(m.corrida.resgate).toEqual({ personagem: "Puff", local: "biblioteca" });
  });
  it("concluir fase gasta 1 bônus", () => expect(m.corrida.conclusao.bonusConsumidos).toBe(1));
  it("concluir fase libera a próxima", () => expect(m.corrida.conclusao.liberaProxima).toBe(true));
  it("concluir fase dá +50", () => expect(m.corrida.conclusao.recompensa).toBe(50));
  it("movimento usa WASD ou setas", () => expect(m.controles.mover).toEqual(["W", "A", "S", "D", "setas"]));
  it("Shift corre", () => expect(m.controles.correr).toEqual(["Shift"]));
  it("Espaço pula", () => expect(m.controles.pular).toEqual(["Espaço"]));
  it("Z ou F dá patada", () => expect(m.controles.patada).toEqual(["Z", "F"]));
  it("X solta miado sônico", () => expect(m.controles.miadoSonico).toEqual(["X"]));
  it("M mia", () => expect(m.controles.miar).toEqual(["M"]));
  it("ESC pausa", () => expect(m.controles.pausar).toEqual(["ESC"]));
  it("arrastar mouse gira câmera", () => expect(m.controles.camera).toBe("arrastar o mouse"));
  it("celular usa toque e tela girada", () => expect(m.controles.celular).toEqual({ botoesToque: true, girarTela: true }));
  it("treino permite qualquer fase", () => expect(m.treino.qualquerFase).toBe(true));
  it("treino não grava progresso", () => expect(m.treino.gravaProgresso).toBe(false));
  it("treino não gasta bônus", () => expect(m.treino.gastaBonus).toBe(false));
});