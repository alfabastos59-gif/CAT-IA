export const ECHO_COOLDOWN_MS = 500;
const WAKE_WINDOW_MS = 8000;

export function voiceQuestion(text: string, armedUntil: number, now: number) {
  const normalized = text.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
  const wake = /\b(quiterio|kiterio|quiteria)\b/.exec(normalized);
  if (wake) {
    const question = text.slice(wake.index + wake[0].length).replace(/^[\s,.!?]+/, "").trim();
    return question ? { question, armedUntil: 0 } : { question: null, armedUntil: now + WAKE_WINDOW_MS };
  }
  return { question: now < armedUntil ? text.trim() || null : null, armedUntil: 0 };
}