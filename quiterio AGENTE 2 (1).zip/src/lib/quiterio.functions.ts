import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const Input = z.object({
  messages: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().max(2000) })).min(1).max(20),
});

export const conversarComQuiterio = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data }) => {
    const { generateResponse, GatewayError } = await import("@lovable.dev/ai-gateway");
    const { contextoBiblioteca } = await import("./biblioteca");
    const { contextoMissaoQuiterio } = await import("./missao-quiterio");
    const ultima = data.messages[data.messages.length - 1]?.content ?? "";
    const instructions = `Você é o Quitério, o gatinho da biblioteca do Colégio Estadual do Campo Maria Quitéria. Fale em português do Brasil, de forma amigável, carinhosa e direta, sem emojis e sem markdown (sua resposta será falada em voz alta). Responda em no máximo 3 frases curtas. Recomende somente livros que aparecem no contexto do acervo abaixo, dizendo título, autor e se está disponível. Nunca invente livros. Se pedirem algo fora do acervo, diga que não encontrou e sugira algo parecido do contexto. Você não tem acesso a dados de alunos nem a quem está com cada livro.

Quando perguntarem sobre a Missão Quitério, participação, desafios, bônus, fases ou controles, responda com as regras oficiais da Missão abaixo, sem desviar para recomendações de livros. Considere o histórico para entender perguntas de continuação. Explique apenas o que foi perguntado, em até 3 frases curtas; se pedirem uma explicação completa, comece pelo acesso e desafios e ofereça continuar com a corrida. Não invente regras, links, critérios de estrelas ou unidade para a recompensa +50. Nunca peça o código de aluno nesta conversa nem afirme que consegue verificar códigos, consultar progresso ou executar ações no jogo.

${contextoMissaoQuiterio()}

CONTEXTO DO ACERVO:
${contextoBiblioteca(ultima)}`;
    try {
      const res = await generateResponse({
        model: "openai/gpt-6-astra",
        instructions,
        input: data.messages.map((m) => ({ role: m.role, content: m.content })),
      });
      let text = "";
      for (const item of res.output ?? []) {
        if (item.type === "message") for (const c of item.content) if (c.type === "output_text") text += c.text;
      }
      return { reply: text.trim() || "Miau... fiquei sem palavras. Pode repetir?" };
    } catch (e) {
      console.error(e);
      if (e instanceof GatewayError && e.httpStatus === 429) return { reply: "Muita gente falando comigo agora. Tente de novo em instantes, tá?" };
      return { reply: "Ops, me enrolei no novelo. Tente de novo daqui a pouco." };
    }
  });
