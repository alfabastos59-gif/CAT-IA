/** Conhecimento da Missão; não executa login, pontuação nem ações do jogo. */
export const MISSAO_QUITERIO = {
  acesso: { codigoIndividual: true, destino: "biblioteca", progressoPorAluno: true },
  desafios: {
    maxLivros: 5,
    perguntasLivro: 4,
    perguntasSurpresa: 6,
    surpresaSemLivros: true,
    coracoes: 3,
    estrelasMin: 0,
    estrelasMax: 3,
  },
  bonus: { somenteLivros: true, exigeMelhora: true, corridasPorBonus: 1 },
  corrida: {
    coracoes: 3,
    fases: ["Fazenda", "Milharal", "Sertão", "Floresta", "Cidade à noite"],
    faseTratores: 4,
    faseMiadoSonico: 4,
    faseResgate: 5,
    resgate: { personagem: "Puff", local: "biblioteca" },
    conclusao: { bonusConsumidos: 1, liberaProxima: true, recompensa: 50 },
  },
  controles: {
    mover: ["W", "A", "S", "D", "setas"],
    correr: ["Shift"],
    pular: ["Espaço"],
    patada: ["Z", "F"],
    miadoSonico: ["X"],
    miar: ["M"],
    pausar: ["ESC"],
    camera: "arrastar o mouse",
    celular: { botoesToque: true, girarTela: true },
  },
  treino: { qualquerFase: true, gravaProgresso: false, gastaBonus: false },
} as const;

export function contextoMissaoQuiterio() {
  const m = MISSAO_QUITERIO;
  return `REGRAS OFICIAIS DA MISSÃO QUITÉRIO:
Para participar, faça login na Missão Quitério com seu código individual de aluno. Se estiver correto, você entra direto na biblioteca. O código é só seu; não compartilhe na conversa. Seu progresso fica salvo por aluno.
Cada livro do aluno vira um cartão de desafio, até ${m.desafios.maxLivros} livros. Há também o Desafio Surpresa, inclusive para quem não tem livros.
Cada desafio de livro tem ${m.desafios.perguntasLivro} perguntas; o Desafio Surpresa tem ${m.desafios.perguntasSurpresa}. Você joga os desafios com ${m.desafios.coracoes} corações e pode ganhar de ${m.desafios.estrelasMin} a ${m.desafios.estrelasMax} estrelas.
Somente desafios de livros dão bônus, e somente quando a nota melhora. O Desafio Surpresa não dá bônus. Cada bônus vale ${m.bonus.corridasPorBonus} corrida: toque em Jogar com o Quitério.
A corrida 3D tem ${m.corrida.fases.length} fases e ${m.corrida.coracoes} corações. Ordem: ${m.corrida.fases.map((fase, i) => `${i + 1}: ${fase}`).join("; ")}.
Na fase ${m.corrida.faseTratores}, cuidado com os tratores; use o miado sônico. Na fase ${m.corrida.faseResgate}, você resgata a ${m.corrida.resgate.personagem} na ${m.corrida.resgate.local}.
Concluir uma fase gasta ${m.corrida.conclusao.bonusConsumidos} bônus, libera a próxima e dá +${m.corrida.conclusao.recompensa}. Não foi informada a unidade dessa recompensa, nem as fórmulas de nota ou estrelas.
Controles: ${m.controles.mover.join(" / ")} para andar; ${m.controles.correr.join(" ou ")} para correr; ${m.controles.pular.join(" ou ")} para pular; ${m.controles.patada.join(" ou ")} para dar patada; ${m.controles.miadoSonico.join(" ou ")} para soltar o miado sônico na fase ${m.corrida.faseMiadoSonico}; ${m.controles.miar.join(" ou ")} para miar; ${m.controles.pausar.join(" ou ")} para pausar; ${m.controles.camera} para girar a câmera.
No celular aparecem botões de toque; gire a tela.
Em Testar fases, você joga qualquer fase sem gravar progresso e sem gastar bônus.
Estas regras descrevem a Missão, não funções desta conversa: você não faz login pelo aluno, não verifica códigos, não acessa progresso e não concede bônus. Não foi informado um endereço de acesso à Missão; não invente links.`;
}