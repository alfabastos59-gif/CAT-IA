import data from "@/data/biblioteca.json";

interface Livro {
  id: string; titulo: string; autor: string | null; descricao: string;
  categoria: string | null; ano: string | number | null;
  quantidade: number | null; quantidade_disponivel: number | null;
}
interface Autor { nome: string; papel: string | null; periodo: string | null; categoria: string | null; frases: string[] }
const db = data as unknown as { instituicao: string; livros: Livro[]; autores: Autor[] };

/** Regras de empréstimo informadas ao Quitério. Ajuste aqui quando a biblioteca definir. */
export const REGRAS_EMPRESTIMO =
  "Cada leitor pode pegar até 2 livros ao mesmo tempo. O prazo de devolução é de 14 dias corridos. A renovação acrescenta 7 dias ao prazo atual e pode ser feita online ou presencialmente na biblioteca. Dúvidas sobre atrasos específicos ou multas devem ser tratadas com a equipe da biblioteca.";

export function norm(s: string | null | undefined) {
  return (s ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
}
const STOP = new Set("a o as os um uma de da do das dos e em no na nos nas por para com que livro livros autor autora tem voces voce sobre me quero procuro biblioteca ha existe algum alguma obra obras ler quiterio oi ola recomenda recomende indica indique gostaria queria pode".split(" "));
const GENEROS: Record<string, string[]> = {
  aventura: ["aventura", "viagem", "jornada", "explora", "pirata", "tesouro", "misterio"],
  ficcao: ["ficcao", "fantasia", "magia", "futuro", "romance", "conto"],
  classico: ["classico", "machado", "alencar", "drummond", "lispector", "literatura brasileira"],
};
function tokens(q: string) {
  const base = norm(q).split(" ").filter((t) => t.length > 1 && !STOP.has(t));
  const extra: string[] = [];
  for (const [g, ws] of Object.entries(GENEROS)) if (base.some((t) => t.startsWith(g.slice(0, 6)))) extra.push(...ws);
  return [...new Set([...base, ...extra])];
}
function situacao(l: Livro) {
  const d = l.quantidade_disponivel ?? 0;
  return d > 0 ? `disponível (${d} de ${l.quantidade ?? d})` : "emprestado no momento";
}
function resumo(l: Livro) {
  const s = l.descricao.replace(/\s+/g, " ").trim();
  return `- "${l.titulo}" — ${l.autor || "autor não informado"} (${l.categoria || "sem categoria"}${l.ano ? `, ${l.ano}` : ""}) · ${situacao(l)}${s ? ` · ${s.slice(0, 220)}` : ""}`;
}

export function buscarLivros(consulta: string, limite = 8) {
  const toks = tokens(consulta);
  if (!toks.length) return [];
  return db.livros
    .map((l) => {
      const t = norm(l.titulo), a = norm(l.autor), c = norm(l.categoria), d = norm(l.descricao);
      let score = 0;
      for (const tk of toks) { if (t.includes(tk)) score += 4; if (a.includes(tk)) score += 3; if (c.includes(tk)) score += 2; if (d.includes(tk)) score += 1; }
      if ((l.quantidade_disponivel ?? 0) > 0) score += 0.5;
      return { l, score };
    })
    .filter((x) => x.score >= 1)
    .sort((x, y) => y.score - x.score)
    .slice(0, limite)
    .map((x) => x.l);
}

export function buscarAutores(consulta: string) {
  const toks = tokens(consulta).filter((t) => t.length > 3);
  return db.autores.filter((a) => toks.some((t) => norm(a.nome).split(" ").includes(t))).slice(0, 3);
}

export function amostraDisponivel(n = 6) {
  const pool = db.livros.filter((l) => (l.quantidade_disponivel ?? 0) > 0);
  const out: Livro[] = [];
  for (let i = 0; i < n && pool.length; i++) out.push(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]!);
  return out;
}

export function contextoBiblioteca(pergunta: string) {
  const cats: Record<string, number> = {};
  for (const l of db.livros) cats[l.categoria || "Outros"] = (cats[l.categoria || "Outros"] ?? 0) + 1;
  const livros = buscarLivros(pergunta);
  const autores = buscarAutores(pergunta);
  const lista = (livros.length ? livros : amostraDisponivel()).map(resumo).join("\n");
  const aut = autores.map((a) => `- ${a.nome}: ${a.papel ?? ""} ${a.periodo ? `(${a.periodo})` : ""}${a.frases[0] ? ` — frase: "${a.frases[0]}"` : ""}`).join("\n");
  return `Biblioteca do ${db.instituicao}. Acervo: ${db.livros.length} títulos. Categorias: ${Object.entries(cats).map(([k, v]) => `${k} (${v})`).join(", ")}.
${livros.length ? "Livros do acervo relacionados à pergunta" : "Sugestões disponíveis do acervo (nenhum resultado direto)"}:
${lista}
${aut ? `Autores cadastrados:\n${aut}` : ""}
Regras de empréstimo: ${REGRAS_EMPRESTIMO}`;
}
